import { Libro, Autor } from '../types';

export const mockAutores: Autor[] = [
  {
    nombre: "Gabriel García Márquez",
    nacionalidad: "Colombiana",
    biografia: "Premio Nobel de Literatura en 1982. Reconocido por su estilo de realismo mágico.",
    foto: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Isabel Allende",
    nacionalidad: "Chilena",
    biografia: "Una de las escritoras más leídas del mundo hispánico. Miembro de la Academia Estadounidense de las Artes y las Letras.",
    foto: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Jorge Luis Borges",
    nacionalidad: "Argentina",
    biografia: "Poeta, ensayista y escritor de cuentos. Figura clave de la literatura fantástica.",
    foto: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Mario Vargas Llosa",
    nacionalidad: "Peruana",
    biografia: "Premio Nobel de Literatura en 2010. Uno de los más importantes novelistas y ensayistas contemporáneos.",
    foto: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Julio Cortázar",
    nacionalidad: "Argentina",
    biografia: "Maestro del relato corto y renovador de la novela contemporánea.",
    foto: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Pablo Neruda",
    nacionalidad: "Chilena",
    biografia: "Premio Nobel de Literatura en 1971. Considerado uno de los mejores y más influyentes artistas de su siglo.",
    foto: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Octavio Paz",
    nacionalidad: "Mexicana",
    biografia: "Premio Nobel de Literatura en 1990. Poeta, ensayista y diplomático mexicano.",
    foto: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Carlos Fuentes",
    nacionalidad: "Mexicana",
    biografia: "Uno de los autores más admirados de la literatura latinoamericana.",
    foto: "https://images.unsplash.com/photo-1490633874781-1c63cc424610?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Federico García Lorca",
    nacionalidad: "Española",
    biografia: "Poeta, dramaturgo y prosista español. Figura principal de la Generación del 27.",
    foto: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=1000"
  },
  {
    nombre: "Miguel de Cervantes",
    nacionalidad: "Española",
    biografia: "El autor más célebre de la literatura española. Creador de Don Quijote.",
    foto: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=1000"
  }
];

export const mockLibros: Libro[] = [
  {
    titulo: "Cien años de soledad",
    autor: "Gabriel García Márquez",
    anioPublicacion: 1967,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Una saga familiar que narra la historia de los Buendía a lo largo de siete generaciones en el pueblo ficticio de Macondo.",
    genero: "Realismo mágico",
    idioma: "Español",
    editorial: "Editorial Sudamericana",
    isbn: "978-0307474728"
  },
  {
    titulo: "El amor en los tiempos del cólera",
    autor: "Gabriel García Márquez",
    anioPublicacion: 1985,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Una historia de amor que atraviesa más de medio siglo entre Florentino Ariza y Fermina Daza.",
    genero: "Novela romántica",
    idioma: "Español",
    editorial: "Editorial Oveja Negra",
    isbn: "978-0307387264"
  },
  {
    titulo: "La casa de los espíritus",
    autor: "Isabel Allende",
    anioPublicacion: 1982,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=1000",
    descripcion: "La saga de la familia Trueba a través de cuatro generaciones en Chile.",
    genero: "Realismo mágico",
    idioma: "Español",
    editorial: "Plaza & Janés",
    isbn: "978-0525433477"
  },
  {
    titulo: "Ficciones",
    autor: "Jorge Luis Borges",
    anioPublicacion: 1944,
    disponibilidad: false,
    imagen: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Colección de cuentos que exploran temas filosóficos y metafísicos.",
    genero: "Ficción",
    idioma: "Español",
    editorial: "Sur",
    isbn: "978-0802130303"
  },
  {
    titulo: "El Aleph",
    autor: "Jorge Luis Borges",
    anioPublicacion: 1949,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Colección de relatos que incluye algunos de los más célebres del autor.",
    genero: "Ficción",
    idioma: "Español",
    editorial: "Losada",
    isbn: "978-0142437888"
  },
  {
    titulo: "La ciudad y los perros",
    autor: "Mario Vargas Llosa",
    anioPublicacion: 1963,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Historia ambientada en el Colegio Militar Leoncio Prado de Lima.",
    genero: "Novela",
    idioma: "Español",
    editorial: "Seix Barral",
    isbn: "978-8432211705"
  },
  {
    titulo: "Rayuela",
    autor: "Julio Cortázar",
    anioPublicacion: 1963,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Una novela experimental que puede leerse en diferentes órdenes.",
    genero: "Novela experimental",
    idioma: "Español",
    editorial: "Pantheon Books",
    isbn: "978-0394752846"
  },
  {
    titulo: "Veinte poemas de amor y una canción desesperada",
    autor: "Pablo Neruda",
    anioPublicacion: 1924,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Una de las obras más célebres de la poesía amorosa en español.",
    genero: "Poesía",
    idioma: "Español",
    editorial: "Editorial Universitaria",
    isbn: "978-0143039969"
  },
  {
    titulo: "El laberinto de la soledad",
    autor: "Octavio Paz",
    anioPublicacion: 1950,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Ensayo sobre la identidad mexicana y la condición humana.",
    genero: "Ensayo",
    idioma: "Español",
    editorial: "Fondo de Cultura Económica",
    isbn: "978-0802150424"
  },
  {
    titulo: "La muerte de Artemio Cruz",
    autor: "Carlos Fuentes",
    anioPublicacion: 1962,
    disponibilidad: false,
    imagen: "https://images.unsplash.com/photo-1490633874781-1c63cc424610?auto=format&fit=crop&q=80&w=1000",
    descripcion: "La vida de un revolucionario mexicano convertido en corrupto cacique.",
    genero: "Novela",
    idioma: "Español",
    editorial: "Fondo de Cultura Económica",
    isbn: "978-0374522835"
  },
  {
    titulo: "Romancero gitano",
    autor: "Federico García Lorca",
    anioPublicacion: 1928,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=1000",
    descripcion: "Colección de romances sobre la vida gitana en Andalucía.",
    genero: "Poesía",
    idioma: "Español",
    editorial: "Espasa Calpe",
    isbn: "978-8423919468"
  },
  {
    titulo: "Don Quijote de la Mancha",
    autor: "Miguel de Cervantes",
    anioPublicacion: 1605,
    disponibilidad: true,
    imagen: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=1000",
    descripcion: "La obra cumbre de la literatura española y una de las más importantes de la literatura universal.",
    genero: "Novela",
    idioma: "Español",
    editorial: "Real Academia Española",
    isbn: "978-8424922474"
  }
];