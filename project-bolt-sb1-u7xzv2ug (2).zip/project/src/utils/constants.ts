export const FILTER_OPTIONS = {
  ALL: 'todos',
  AVAILABLE: 'disponibles',
  UNAVAILABLE: 'nodisponibles'
} as const;

export const TABS = {
  BOOKS: 'libros',
  AUTHORS: 'autores'
} as const;